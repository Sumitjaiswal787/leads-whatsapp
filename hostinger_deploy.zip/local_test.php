<?php
include 'config/config.php';

echo "Testing Localhost Connectivity...\n";
echo "Host: " . DB_HOST . "\n";
echo "User: " . DB_USER . "\n";
echo "DB: " . DB_NAME . "\n";

if ($conn->connect_error) {
    echo "FAILED: " . $conn->connect_error . "\n";
} else {
    echo "SUCCESS: Local database connected successfully.\n";
    
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    if ($result) {
        $row = $result->fetch_assoc();
        echo "Found " . $row['count'] . " users in the database.\n";
    }
}
?>
